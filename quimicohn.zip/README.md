"# colegioquimico" 
Sitio Web para el Colegio Químico y Farmacéutico de Honduras. 

Sitio Web desarrollado Por el Ingeniero Marvin Ricardo Toro
Inicio del Proyecto Diciembre del 2019

Diseñador Web :Lic. Salomon Chavarria

Desarrollado en PHP7, HTML5 , CSS3 , Javascript, Bootstrap 4, FontAwesome, Jquery. 


:)