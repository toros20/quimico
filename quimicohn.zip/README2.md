"# quimico" 
