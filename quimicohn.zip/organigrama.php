<?php
    //importamos el head , con los css 
    include('head.php');
?>
<body>

<div id="wrapper">
    <?php
        //importamos el header y el menu 
        include('menu.php');
    ?>
<!-- About Page 1 Area Start Here -->
<div class="about-page1-area">
    <div class="container">
        <div class="row about-page1-inner">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                <div class="about-page-content-holder">
                    <div class="content-box">
                        <h2>Nuestro Organigrama</h2>
                    </div>
                </div>
            </div>
            <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="about-page-img-holder" style="text-align: center;">
                    <img src="img/organigrama.jpg" class="img-responsive" alt="logo colegio quimico farmaceutico de honduras" style="display: inline-block;">
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- About Page 1 Area End Here -->

</div> <!--End Of Wraper-->

</body>

 <!-- Main Body Area End Here -->
 <?php
        //importamos el footer con los js 
        include('footer.php');
    ?>
</html>