<?php
    //importamos el head , con los css 
    include('head.php');
?>
<body>

<div id="wrapper">
    <?php
        //importamos el header y el menu 
        include('menu.php');
    ?>
  <!-- Inner Page Banner Area Start Here -->
           
                <div class="row" align="center" style="padding-top: 10px;">
                    <h3><a href="noticias.php"> Regresar a Noticias</a></h3>
                </div>
           
        </div>
        <!-- Inner Page Banner Area End Here -->
        <!-- Research Details Page Area Start Here -->
        <div class="research-details-page-area" style="padding: 1px 0 74px;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                        <div class="row research-details-inner">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <img src="img/research/16.jpg" class="img-responsive" alt="research">
                                <h2 class="title-default-left-bold title-bar-high"><a href="#">Future UX Design Tecnique</a></h2>
                                <p>Bimply dummy text of the printing and typesetting istryrem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchangedwhen an unknown printer took a galley of type and scrambled.when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
                                <p>Bimply dummy text of the printing and typesetting istryrem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                                <p><span>Bimply dummy text of the printing and typesetting istryrem Ipsum has been the industry's standard dummy type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchan scrambled.</span></p>
                                <p>Bimply dummy text of the printing and typesetting istryrem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchangedwhen an unknown printer took a galley of type and scrambled.when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
                            </div>
                        </div>
                    </div>
                 
                </div>
            </div>
        </div>
        <!-- Research Details Page Area End Here -->
        
</div> <!--End Of Wraper-->

</body>

 <!-- Main Body Area End Here -->
 <?php
        //importamos el footer con los js 
        include('footer.php');
    ?>
</html>